import { Component } from '@angular/core';
import { Storage } from '@ionic/storage';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-profile',
  templateUrl: 'profile.html'
})
export class ProfilePage {
  baby: string;
  age: string;
  weight: string;
  height: string;


  constructor(public navCtrl: NavController, public storage: Storage) {

  }
  setPerson() {
    this.storage.set('baby', this.baby)
    this.storage.set('age', this.age)
    this.storage.set('weight', this.weight)
    this.storage.set('height', this.height)
    alert("Profile Update!");

}


}
