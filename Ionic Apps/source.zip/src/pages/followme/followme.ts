import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
    selector: 'page-mine',
    templateUrl: 'followme.html'
})
export class FollowMe {
    constructor(public navCtrl: NavController) {
    }
}
