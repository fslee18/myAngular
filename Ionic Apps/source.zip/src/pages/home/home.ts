import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Storage } from '@ionic/storage';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  baby: string;
  age: string;
  weight: string;
  height: string;

 constructor(public navCtrl: NavController, public storage: Storage) {
      // Prepare storage.
      storage.ready().then(() => {
          // Store some data if none exists.
          if(!this.storage.get('baby')) {
              console.log("Storing default data!");
              this.storage.set('baby', 'This is the default baby');
              this.storage.set('age',  'This is the default age.');
              this.storage.set('weight',  'This is the default age.');
              this.storage.set('height',  'This is the default age.');
          }      
      });
  }

  // Executes every time page is viewed.
  ionViewWillEnter(){
    this.displayData();
  }

  // Uses a promise to get data.
  displayData() {      
      this.storage.get('baby').then((baby) => {
          this.baby = baby;
        });
      this.storage.get('age').then((age) => {
          this.age = age;
        });
      this.storage.get('weight').then((weight) => {
        this.weight = weight;
        });
    this.storage.get('height').then((height) => {
        this.height = height;
        });
  }
}
