
import { Component } from '@angular/core';
import { Http, Response} from '@angular/http';
import { NavController } from 'ionic-angular';
import 'rxjs/add/operator/map';
 
@Component({
  selector: 'page-about',
  template:  `
  <ion-header>
    <ion-navbar>
      <ion-title>
       Weather Forecast for your Location
      </ion-title>
    </ion-navbar>
  </ion-header>
   
  <ion-content padding>

  
  <ion-list>
  <ion-item>
    <ion-label>Select your location</ion-label>
    <ion-select [(ngModel)]="mylocation" multiple="false">
      <ion-option value="vancouver">Vancouver</ion-option>
      <ion-option value="toronto">Toronto</ion-option>
      <ion-option value="edmonton">Edmonto</ion-option>
      <ion-option value="calgary">Calgary</ion-option>
      <ion-option value="winnipeg">Winnipeg</ion-option>
      <ion-option value="saskatoon">Saskatoon</ion-option>
    </ion-select>
  </ion-item>
</ion-list>
<button ion-button item-right (click)="getRequest(mylocation)">check weather</button>
<br />
{{ myBody}}
<br />
{{ myTemp }}
<br />
<ion-img width="30" height="30" src={{myImg}}></ion-img>

    
</ion-content>
  
  `
  
  

})
export class AboutPage {
  mylocation: any;
  myBody: any;
  myTemp: any;
  myImg: any;
  url: string;

  constructor(public navCtrl: NavController, public http: Http) {

    
  }
 
  getRequest(mylocation) {
    
    this.url= "https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20weather.forecast%20where%20woeid%20in%20(select%20woeid%20from%20geo.places(1)%20where%20text%3D%22" + this.mylocation + "%22)%20and%20u%3D'c'&format=json&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys";
    console.log(this.url);
    this.http.get(this.url)
    .map(res => res.json())
    .subscribe(data => {
      // console.log(data.query.results.channel.item.condition);
      this.myBody = data.query.results.channel.item.condition.text;
      this.myTemp = data.query.results.channel.item.condition.temp + "(℃)";
      this.myImg = "http://l.yimg.com/a/i/us/we/52/"+ data.query.results.channel.item.condition.code+ ".gif";
      console.log(this.myBody);
    
     }, error => {
    
      console.log(error);// Error getting the data
    });
    
  }


}
