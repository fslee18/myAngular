
import { Component } from '@angular/core';
import { Http, Response } from '@angular/http';
import { NavController } from 'ionic-angular';
import 'rxjs/add/operator/map';
 
@Component({
  selector: 'page-about',
  templateUrl: 'about.html'
})
export class AboutPage {
  constructor(public navCtrl: NavController, public http: Http) {
  }
 
  getRequest() {
    // var headers = new Headers();
    // headers.append("Accept", 'application/json');
    // headers.append('Content-Type', 'application/json' );
    // let options = new RequestOptions({ headers: headers });
 
    // let postParams = {

    //   albumId: 1
    // }
    
     return this.http.get("http://jsonplaceholder.typicode.com/albums/1")
      .map(res => res.json())
      .subscribe(data => {
       console.log(data.title);
       }, error => {
        console.log(error);// Error getting the data
      });
  }
}
